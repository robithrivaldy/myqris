import 'package:flutter/material.dart';
import 'package:myqris/utils/constants.dart';

class HomeBlank extends StatelessWidget {
  const HomeBlank({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
