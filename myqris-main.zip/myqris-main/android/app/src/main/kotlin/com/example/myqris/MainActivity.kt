package com.example.myqris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
